<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>rodape</title>
	<link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <link type="text/css" rel="stylesheet" href="../materialize/css/materialize.min.css"  media="screen,projection"/>
    <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
</head>
<body>
    
<footer class="page-footer">
                       
          <div class="footer-copyright">
            <div class="container">
            © 201 Copyright Text
            <a class="grey-text text-lighten-4 right" href="../index.php">Voltar</a>
 
            </div>
          </div>
        </footer>
</body>
</html>