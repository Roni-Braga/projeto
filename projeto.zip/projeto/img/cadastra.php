<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>incluir</title>
	<link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <link type="text/css" rel="stylesheet" href="../materialize/css/materialize.min.css"  media="screen,projection"/>
    <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
</head>
<style type="text/css">

.cor{
	background-color:#CDB79E;
	width: 600px;;
	border-radius: 10px;
	font-family: arial;
	margin-left: 200px;
	color:#FAEBD7;
}
h3{
	color:white;
	text-align:center;
}


</style>
<body>

<?php
include_once '../materialize/conexao.php';
include_once '../nav.bar.php';


$chave = $_SESSION['chave'] ??'';
$sql = "SELECT * FROM veiculo WHERE codigo = $chave";
if($resultado = mysqli_query($conexao,$sql)){
    // executou sem erro a conexao e o sql sem problema
if($campo = mysqli_fetch_array($resultado))
{
// se existe, sai fora

echo"<script>alert('Veiculo já cadastrado: {$chave}');</script>";
echo"<script>document.location.href='../index.php';</script>";
}else{
    // cadastra
	
}

}

?>

  
<div class="cor">
<h3>Cadastrar Veiculos</h3>
<form action="../materialize/processa.php" method="POST" enctype="multipart/form-data">
   <div class="row">
	   <div class="col">
	 Codigo do Veiculo:
<input type="text" name="codigo" disabled value="<?php echo $chave;?>" style="width:130px;">		
Nome do Veículo:
<input type="text" name="veiculo" autofocus style="width:130px;">
	
</div>
</div>
	<div class="row">
		<div class="col">
		Marca do Veículo:
		<input type="text" name="marca" style="width:130px;">
		Modelo do Veículo:
		<input type="text" name="modelo" style="width:130px;">
</div>
</div>
<div class="row">
	<div class="col">
		Data de Fabricação:
		<input type="date" name="fabricacao"style="width:130px;">
		Quantidade em Estoque:
		<input type="number" name="quantidade"style="width:130px;">
		
</div>
</div>
<div class="row">
	<div class="col">
	<div class="file-field input-field">
      <div class="btn">
        <span>Imagem</span>
        <input type="file" multiple name="foto">
      </div>
      <div class="file-path-wrapper">
        <input class="file-path validate" type="text"  placeholder="Selecione um Arquivo" >
      </div>
    </div>
</div>
<button class="waves-effect waves-light btn" style="margin:10px; margin-left:100px;">Cadastrar</button>
</div>



</div>
</form>




<?php
include_once 'rodape.php';
?>

<script type="text/javascript" src="https://code.jquery.com/jquery-3.2.1.min.js"></>
      <script type="text/javascript" src="../materialize/js/materialize.min.js"></script>

</body>
</html>