console.log(typeof Object)

class produto{}
console.log(typeof produto)