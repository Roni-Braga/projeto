{
    {
        {
            {
                var sera = "Sera !!!"
            }
        }
    }
}
console.log(sera)

function teste(){
    var local = 123
    
}
teste()
console.log(local)