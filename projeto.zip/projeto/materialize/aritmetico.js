const [a,b,c,d] = [1,3,7,9]

const soma = a + b + c + d
const subtracao = d-c
const multiplicacao = a*d
const divisao = c/b
const modulo = b % 2

console.log(soma)
console.log(subtracao)
console.log(divisao)
console.log(multiplicacao)
console.log(modulo)
