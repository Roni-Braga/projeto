function tratarErroeLancar(erro) {
//throw new Error("...")
throw 10
}


function imprimirNomeGritado(obj){
    try{
        console.log(obj.name.toUppercase() + '!!!')
}catch(e){
    tratarErroeLancar(e)
} 
}
const obj = {nome: "Ronielson"}
imprimirNomeGritado(obj)