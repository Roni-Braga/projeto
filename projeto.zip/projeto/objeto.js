const  prod1 = {}
prod1.nome = "Celular JS PRIME"
prod1.preco = 599.90
prod1['desconto legal'] = 0.40 // evitar atributos com espaço
console.log(prod1)

const prod2 ={
nome:"camisa",
preco: 79.90


}
console.log(prod2)